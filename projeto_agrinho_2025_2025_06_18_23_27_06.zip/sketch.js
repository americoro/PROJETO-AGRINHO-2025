let gado = []; // Array para armazenar os objetos de gado
let cochoAgua;
let cochoComida;
let painelInfo;

function setup() {
  createCanvas(800, 600); // Cria a tela do projeto
  // Inicializa o gado (ex: 3 vacas, 2 bois)
  for (let i = 0; i < 5; i++) {
    gado.push(new Bovino(random(width), random(height), i % 2 == 0 ? 'leiteiro' : 'corte'));
  }
  // Cria os elementos do cenário
  cochoAgua = new Cocho(100, 500, 'agua');
  cochoComida = new Cocho(700, 500, 'comida');

  // Inicializa o painel de informações
  painelInfo = new PainelInfo();
}

function draw() {
  background(100, 200, 100); // Fundo verde (pasto)

  // Desenha os elementos do cenário
  cochoAgua.display();
  cochoComida.display();

  // Atualiza e desenha cada bovino
  for (let i = 0; i < gado.length; i++) {
    gado[i].update();
    gado[i].display();
    // Verifica interação com os cochos
    gado[i].checkCocho(cochoAgua);
    gado[i].checkCocho(cochoComida);
  }

  // Desenha o painel de informações
  painelInfo.display();
}

function mousePressed() {
  // Verifica se clicou em algum bovino
  for (let i = 0; i < gado.length; i++) {
    if (dist(mouseX, mouseY, gado[i].x, gado[i].y) < 30) { // Distância para clique
      painelInfo.updateInfo(gado[i].tipoGado); // Atualiza o painel com informações do gado clicado
      break;
    }
  }
}

// --- Classes para os objetos ---

// Classe Bovino
class Bovino {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.tamanho = 40;
    this.velocidade = random(0.5, 2);
    this.direcaoX = random([-1, 1]);
    this.direcaoY = random([-1, 1]);
    this.tipoGado = tipo; // 'leiteiro' ou 'corte'
    this.fome = 100;
    this.sede = 100;
  }

  update() {
    // Movimentação aleatória
    this.x += this.velocidade * this.direcaoX;
    this.y += this.velocidade * this.direcaoY;

    // Colisão com as bordas da tela
    if (this.x < 0 || this.x > width) this.direcaoX *= -1;
    if (this.y < 0 || this.y > height) this.direcaoY *= -1;

    // Diminui fome e sede
    this.fome -= 0.1;
    this.sede -= 0.1;
    this.fome = constrain(this.fome, 0, 100);
    this.sede = constrain(this.sede, 0, 100);
  }

  display() {
    // Desenha o corpo do bovino (simplificado)
    fill(200, 150, 100); // Cor marrom clara
    ellipse(this.x, this.y, this.tamanho, this.tamanho * 0.8);
    // Adiciona manchas ou detalhes para diferenciar
    if (this.tipoGado === 'leiteiro') {
      fill(255); // Branco para manchas
      ellipse(this.x - 10, this.y - 5, 10, 8);
      ellipse(this.x + 10, this.y + 5, 12, 10);
    }
    // Desenha orelhas, chifres e cauda se quiser detalhar mais
    // Textura da fome/sede
    noStroke();
    fill(255, 0, 0, map(this.fome, 0, 100, 200, 0)); // Transparência vermelha para fome
    rect(this.x - this.tamanho / 2, this.y - this.tamanho / 2 - 10, this.fome * (this.tamanho / 100), 5);
    fill(0, 0, 255, map(this.sede, 0, 100, 200, 0)); // Transparência azul para sede
    rect(this.x - this.tamanho / 2, this.y - this.tamanho / 2 - 18, this.sede * (this.tamanho / 100), 5);

    // Texto com tipo de gado ao passar o mouse
    if (dist(mouseX, mouseY, this.x, this.y) < 30) {
        fill(0);
        textSize(12);
        textAlign(CENTER);
        text(this.tipoGado.charAt(0).toUpperCase() + this.tipoGado.slice(1), this.x, this.y - this.tamanho / 2 - 25);
    }
  }

  checkCocho(cocho) {
    if (dist(this.x, this.y, cocho.x, cocho.y) < 50) { // Se estiver perto do cocho
      if (cocho.tipo === 'agua') {
        this.sede = 100; // Bebe água
      } else if (cocho.tipo === 'comida') {
        this.fome = 100; // Come
      }
    }
  }
}

// Classe Cocho
class Cocho {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.largura = 80;
    this.altura = 40;
    this.tipo = tipo; // 'agua' ou 'comida'
  }

  display() {
    if (this.tipo === 'agua') {
      fill(0, 150, 255); // Azul para água
    } else {
      fill(139, 69, 19); // Marrom para comida
    }
    rect(this.x - this.largura / 2, this.y - this.altura / 2, this.largura, this.altura);
    fill(255);
    textSize(12);
    textAlign(CENTER);
    text(this.tipo.charAt(0).toUpperCase() + this.tipo.slice(1), this.x, this.y + this.altura / 2 + 15);
  }
}

// Classe PainelInfo
class PainelInfo {
  constructor() {
    this.infoTexto = "Clique em um bovino para saber mais!";
  }

  updateInfo(tipo) {
    if (tipo === 'leiteiro') {
      this.infoTexto = "Vaca Leiteira: Criada principalmente para produção de leite. Geralmente são da raça Holandesa ou Jersey.";
    } else if (tipo === 'corte') {
      this.infoTexto = "Boi de Corte: Criado para produção de carne. Exemplos: Nelore, Angus. Crescem rápido e têm boa massa muscular.";
    } else {
      this.infoTexto = "Tipo de gado desconhecido.";
    }
  }

  display() {
    fill(255, 255, 200, 200); // Fundo claro para o painel
    rect(width / 2 - 200, 20, 400, 80);
    fill(0);
    textSize(14);
    textAlign(CENTER, CENTER);
    text(this.infoTexto, width / 2, 60);
  }
}